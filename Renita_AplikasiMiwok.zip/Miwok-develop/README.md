# Miwok
Esercizi con app Miwok
https://classroom.udacity.com/courses/ud839

Rif GIT:
https://github.com/udacity/ud839_CustomAdapter_Example
https://github.com/udacity/ud839_ViewPager_Example
https://github.com/udacity/ud839_Miwok

Casi risolti:
1) Adapter per le liste
2) play di mp3 (usabile anche per video)

TODO:
1) usare le https://developer.android.com/guide/topics/ui/layout/recyclerview.html
2) sostituire lista main statica con lista dinamica
3) mettere classe di utility stile data provider per l'elenco delle parole
4) sostituire i vari layout con le ConstraintLayout (vedere https://github.com/chrisbanes/cheesesquare)

Altri TODO
// TODO see https://pttrns.com/android-patterns?scid=31
// TODO see global action https://developer.android.com/guide/navigation/navigation-design-graph
// TODO see https://developer.android.com/guide/navigation
// TODO see https://www.youtube.com/watch?v=Y0Cs2MQxyIs
